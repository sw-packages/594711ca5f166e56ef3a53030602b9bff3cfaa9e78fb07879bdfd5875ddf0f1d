#ifndef XML_INCLUDE_H_PRIVATE__
#define XML_INCLUDE_H_PRIVATE__

#include <libxml/xinclude.h>

XML_HIDDEN int
xmlXIncludeSetStreamingMode(xmlXIncludeCtxtPtr ctxt, int mode);

#endif /* XML_INCLUDE_H_PRIVATE__ */
